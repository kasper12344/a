import {applyTheme as _applyTheme} from './theme-panel.generated.js';
export const applyTheme = _applyTheme;
