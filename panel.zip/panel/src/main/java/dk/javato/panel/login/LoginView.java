package dk.javato.panel.login;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.login.LoginForm;
import com.vaadin.flow.component.login.LoginI18n;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@PageTitle("Panel Login")
@Route(value = "")
public class LoginView extends Div {

    public LoginView() {
        VerticalLayout layout = new VerticalLayout();
        layout.setWidth("100%");
        layout.setHeight("100vh");
        layout.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
        layout.setAlignItems(FlexComponent.Alignment.CENTER);
        layout.setPadding(false);
        layout.setMargin(false);

        LoginI18n i18n = LoginI18n.createDefault();
        i18n.getForm().setTitle("Log in");
        i18n.getForm().setUsername("Brugernavn");
        i18n.getForm().setPassword("Adgangskode");
        i18n.getForm().setSubmit("Login");
        i18n.getForm().setForgotPassword("Glemt adgangskode?");
        i18n.getErrorMessage().setTitle("Der skete en fejl!");
        i18n.getErrorMessage().setMessage("Ugyldig brugernavn eller adgangskode.");

        LoginForm loginForm = new LoginForm();
        loginForm.setI18n(i18n);
        loginForm.getElement().setAttribute("no-autofocus", "");

        Div formWrapper = new Div(loginForm);
        formWrapper.getElement().getStyle().set("border-radius", "10px");
        formWrapper.getElement().getStyle().set("background-color", "#303D51");
        formWrapper.getElement().getStyle().set("padding", "20px");
        formWrapper.getElement().getStyle().set("margin", "0");
        formWrapper.getElement().getStyle().set("box-shadow", "0 4px 15px rgba(0, 0, 0, 0.2)");

        layout.add(formWrapper);
        add(layout);

        loginForm.addLoginListener(event -> {
            if ("admin".equals(event.getUsername()) && "admin".equals(event.getPassword())) {
                UI.getCurrent().navigate("forside");
            } else {
                loginForm.setError(true);
            }
        });
    }
}
