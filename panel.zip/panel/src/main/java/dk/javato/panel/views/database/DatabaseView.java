package dk.javato.panel.views.database;

import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterListener;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import dk.javato.panel.utils.IsUserLoggedIn;
import dk.javato.panel.views.MainLayout;

@PageTitle("Database")
@Route(value = "database", layout = MainLayout.class)
public class DatabaseView extends Composite<VerticalLayout> implements BeforeEnterListener {

    public DatabaseView() {
        getContent().setWidth("100%");
        getContent().getStyle().set("flex-grow", "1");
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (!IsUserLoggedIn.isUserLoggedIn()) {
            event.forwardTo("");
        }
    }

}
