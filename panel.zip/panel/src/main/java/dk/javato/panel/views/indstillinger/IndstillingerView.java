package dk.javato.panel.views.indstillinger;

import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterListener;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import dk.javato.panel.utils.IsUserLoggedIn;
import dk.javato.panel.views.MainLayout;

@PageTitle("Sider")
@Route(value = "indstillinger", layout = MainLayout.class)
public class IndstillingerView extends Composite<VerticalLayout> implements BeforeEnterListener {

    public IndstillingerView() {
        getContent().setWidth("100%");
        getContent().getStyle().set("flex-grow", "1");
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (!IsUserLoggedIn.isUserLoggedIn()) {
            event.forwardTo("");
        }
    }

}
