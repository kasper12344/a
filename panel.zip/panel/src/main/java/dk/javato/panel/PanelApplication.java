package dk.javato.panel;

import com.vaadin.flow.theme.lumo.Lumo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.vaadin.flow.theme.Theme;
import com.vaadin.flow.component.page.AppShellConfigurator;

@SpringBootApplication
@Theme(value = "panel", variant = Lumo.DARK)
public class PanelApplication implements AppShellConfigurator {

    public static void main(String[] args) {
        SpringApplication.run(PanelApplication.class, args);
    }

}
