package dk.javato.panel.utils;

import com.vaadin.flow.server.VaadinSession;

public class IsUserLoggedIn {

    public static boolean isUserLoggedIn() {
        return VaadinSession.getCurrent().getAttribute("user") != null;
    }

}
